# DEST_V1.0

this DIY project for DEST [DIGITAL DESK PET]

fell free to download and modify the code for your own DEST

you need this for arduino ide :<br>
U8g2 oled libbrary<br>
Vl53L0X  libbrary<br>
wemos d1 mini board instaled<br>

full video on :<br>
https://youtu.be/KCPcR1GBXes
